<!DOCTYPE html>
<html lang="en">
<head>
    <base href='<?php echo base_url('homeassets/');?>'>
    <meta charset="UTF-8">
    <meta name="description" content="Bizorm - One page apps landing page">
    <meta name="keywords" content="apps, Bootstrap, Landing page, Template, Business, One page ">
    <meta name="author" content="ThemeAtelier">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- ========== Title ========== -->
    <title>Bizorm - One page apps landing page</title>
    <!-- ========== Favicon Ico ========== -->
    <link rel="icon" href="fav.ico">
    <!-- ========== STYLESHEETS ========== -->
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Fonts Awesome CSS -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Material icons css -->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Stroke icon CSS -->
    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <!-- IcoFont CSS -->
    <link href="css/icofont.min.css" rel="stylesheet">
    <!-- Owl-carousel CSS -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- Modal Video CSS -->
    <link href="css/modal-video.min.css" rel="stylesheet" />
    <!-- magnific CSS -->
    <link href="css/magnific-popup.css" rel="stylesheet" />
    <!-- Animate CSS -->
    <link href="css/animate.min.css" rel="stylesheet" />
    <!-- Margins CSS -->
    <link rel="stylesheet" href="css/margins.css">
    <!-- Paddings CSS -->
    <link rel="stylesheet" href="css/paddings.css">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" href="css/colors/blue.css">
	<!-- teamplate colors -->
	<!-- <link href="css/colors/blue.css" rel="stylesheet"> -->
	<!-- <link href="css/colors/orange.css" rel="stylesheet"> -->
	<!-- <link href="css/colors/purple.css" rel="stylesheet"> -->
	<!-- <link href="css/colors/pink.css" rel="stylesheet"> -->
	<!-- <link href="css/colors/brown.css" rel="stylesheet"> -->
	<!-- <link href="css/colors/light-blue.css" rel="stylesheet"> -->
	<!-- <link href="css/colors/light-green.css" rel="stylesheet"> -->
	<!-- <link href="css/colors/green.css" rel="stylesheet"> -->
	<!-- <link href="css/colors/dark.css" rel="stylesheet"> -->
</head>
<body data-spy="scroll" data-target="#navbarCodeply" data-offset="70">
    <!-- ========== preloader Start ========== -->
    <div class="preloader">
        <div class="status">
            <div class="loader">
                <svg class="circular" viewbox="25 25 50 50">
                    <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
                </svg>
            </div>
        </div>
    </div>
    <!-- ========== preloader End ========== -->
    <!-- ========== Header ========== -->
    <nav class="navbar navbar-inverse navbar-expand-lg header-nav fixed-top header">
        <div class="container">
            <!-- Add your logo text or change logo image -->
            <a class="navbar-brand logo" href="<?php echo base_url('/');?>" >
                <!-- Bizorm -->
                <img class="logo-dark" src="img/logo.png" alt="bizorm"/ style="width: 70%;">
                <img class="logo-light" src="img/logo-light.png" alt="Bizorm"/ style="width: 70%;">
            </a>
            <!-- <img src="yourlogo.png" alt="Logo"> -->
            <button class="navbar-toggler pull-right" type="button" data-toggle="collapse" data-target="#navbarCodeply">
                <i class="icofont-navigation-menu"></i>
            </button>
        
            <div class="collapse navbar-collapse" id="navbarCodeply">
                <ul class="nav navbar-nav ml-auto">
                    <li><a class="nav-link" href="#home">Home</a></li>
                    <li><a class="nav-link" href="#features">Features</a></li>
                    <li><a class="nav-link" href="#about">About</a></li>
                    <li><a class="nav-link" href="#screenshots">Screenshots</a></li>
                    <li><a class="nav-link" href="#pricing">Pricing</a></li>
                    <li>
                            <a class="nav-link" href="#blog">Blog</a>
                            <span class="sub-menu-toggle" role="navigation" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                               <i class="icofont-rounded-down"></i>
                            </span>
                            <ul class="sub-menu">
                                <li><a href="blog.html">Blog full width</a></li>
                                <li><a href="blog-2-col.html">Blog 2 column</a></li>
                                <li><a href="blog-3-col.html">Blog 3 column</a></li>
                                <li><a href="blog-left-sidebar.html">Blog left sidebar</a></li>
                                <li><a href="blog-right-sidebar.html">Blog right sidebar</a></li>
                                <li><a href="single.html">Single blog</a></li>
                                <li><a href="single-left-sidebar.html">Single left sidebar</a></li>
                                <li><a href="single-right-sidebar.html">Single right sidebar</a></li>
                            </ul>
                         </li>
                    <li><a class="nav-link" href="#contact">Contact</a></li>
                    <li><a class="nav-link" href="#subscription">Subscribe</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- ========== Header End ========== -->
    <!-- ========== hero section ========== -->
    <section id="home" class="text-left hero-section bg-gredient">
        <div class="container">
            <div class="row align-items-center">
                <div class="hero-content col-lg-6 p-175px-tb lg-p-175px-t lg-p-100px-b md-p-100px-t md-p-50px-b">
                    <h2 class="wow fadeInLeft" data-wow-delay=".1s">Bizorm is best for<br><span id="typed" style="white-space:pre;"></span></h2>
                    <p class="wow fadeInLeft" data-wow-delay=".2s">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry standard dummy text ever since the typesetting.
                    </p>
                    <a href="<?php echo base_url('/login');?>" class="primary-btn wow fadeInLeft" data-wow-delay=".3s">Login</a>
                </div>
                <div class="promo-image d-none d-lg-block">
                    <img class="img-fluid" data-wow-delay=".3s" src="img/hero-mockup.png" alt="" />
                </div>
            </div>
        </div>
    </section>
    <!-- ========== hero section  End ========== -->
    <!-- ========== features section  ========== -->
    <section id="features" class="pt100 pb100">
        <div class="container">
			<!-- Section title start -->
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-10 offset-lg-3 offset-md-2 offset-sm-1">
                    <div class="section-title text-center mb60">
                        <h2 class="wow fadeIn" data-wow-delay=".2s">Amazing <span>Features</span></h2>
                        <hr class="lines wow zoomIn" data-wow-delay=".3s">
                        <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.
                        </p>
                    </div>
                </div>
            </div>
			<!-- Section title end -->
            <div class="row align-items-center">
                <div class="col-lg-4 text-center text-lg-right">
                    <div class="media flex-column wow fadeInLeft" data-wow-delay=".1s">
                        <div class="media-icon ml-auto">
                            <i class="pe-7s-refresh-2"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Responsive design</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
					<!-- Single left feature end -->
                    <div class="media flex-column wow fadeInLeft" data-wow-delay=".2s">
                        <div class="media-icon ml-auto">
                            <i class="pe-7s-rocket"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Bootstrap framework</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
					<!-- Single left feature end -->
                    <div class="media flex-column wow fadeInLeft" data-wow-delay=".3s">
                        <div class="media-icon ml-auto">
                            <i class="pe-7s-settings"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Pixel perfect design</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
					<!-- Single left feature end -->
                </div>
                <div class="col-lg-4 text-center">
                    <img class="img-fluid wow zoomIn" data-wow-delay=".3s" src="img/about-img.jpg" alt="" />
                </div>
                <div class="col-lg-4 text-center text-lg-left">
                    <div class="media flex-column wow fadeInRight" data-wow-delay=".1s">
                        <div class="media-icon mr-auto">
                            <i class="pe-7s-shield"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Unique Design</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
					<!-- Single right feature end -->
                    <div class="media flex-column wow fadeInRight" data-wow-delay=".2s">
                        <div class="media-icon mr-auto">
                            <i class="pe-7s-smile"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>CSS3 Animations</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
					<!-- Single right feature end -->
                    <div class="media flex-column wow fadeInRight" data-wow-delay=".3s">
                        <div class="media-icon mr-auto">
                            <i class="pe-7s-search"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Working Contact Form</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
					<!-- Single right feature end -->
                </div>
            </div>
        </div>
    </section>
    <!-- ========== features section End ========== -->

    <!-- ========== about section  ========== -->
    <section id="about" class="pt100 pb100 bg-gray">
        <div class="container">
			<!-- Section title start -->
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-10 offset-lg-3 offset-md-2 offset-sm-1">
                    <div class="section-title text-center mb60">
                        <h2 class="wow fadeIn" data-wow-delay=".2s">About <span>Bizorm</span></h2>
                        <hr class="lines wow zoomIn" data-wow-delay=".3s">
                        <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                    </div>
                </div>
            </div>
			<!-- Section title end -->
            <div class="row about-boxes">
                <div class="col-lg-4 col-md-6">
                    <div class="media flex-column wow fadeIn" data-wow-delay=".1s">
                        <div class="media-icon m-auto">
                            <i class="pe-7s-box1"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Blog page included</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
                </div>
				<!-- Single about box end -->
                <div class="col-lg-4 col-md-6">
                    <div class="media flex-column wow fadeIn" data-wow-delay=".3s">
                        <div class="media-icon m-auto">
                            <i class="pe-7s-check"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>W3C Valid HTML</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
                </div>
				<!-- Single about box end -->
                <div class="col-lg-4 col-md-6">
                    <div class="media flex-column wow fadeIn" data-wow-delay=".3s">
                        <div class="media-icon m-auto">
                            <i class="pe-7s-look"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Very Easy to Customize</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
                </div>
				<!-- Single about box end -->
                <div class="col-lg-4 col-md-6">
                    <div class="media flex-column wow fadeIn" data-wow-delay=".4s">
                        <div class="media-icon m-auto">
                            <i class="pe-7s-magic-wand"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Google fonts used</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
                </div>
				<!-- Single about box end -->
                <div class="col-lg-4 col-md-6">
                    <div class="media flex-column wow fadeIn" data-wow-delay=".5s">
                        <div class="media-icon m-auto">
                            <i class="pe-7s-graph1"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>SEO friendly</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
                </div>
				<!-- Single about box end -->
                <div class="col-lg-4 col-md-6">
                    <div class="media flex-column wow fadeIn" data-wow-delay=".6s">
                        <div class="media-icon m-auto">
                            <i class="pe-7s-display2"></i>
                        </div>
                        <div class="media-body m-20px-t">
                            <h5>Well documented</h5>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                        </div>
                    </div>
                </div>
				<!-- Single about box end -->
            </div>
        </div>
    </section>
    <!-- ========== about section End ========== -->
	
    <!-- ========== about intro section  ========== -->
    <section id="about-intro">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 pt50">
                    <img class="img-fluid wow zoomIn" data-wow-delay=".3s" src="img/hero-mockup.png" alt="" />
                </div>
                <div class="col-lg-6 pt50 pb50">
                    <h2 class="wow fadeInLeft mb30" data-wow-delay=".1s">Showcase your app with Bizorm's</h2>
                    <p class="wow fadeInLeft mb30" data-wow-delay=".2s">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry standard dummy text ever since the typesetting. Lorem Ipsum has been the industry's typesetting industry standard.
                    </p>

                    <a href="#" class="primary-btn wow zoomIn" data-wow-delay=".3s">Read more</a>
                </div>
                <!-- Special feature contenet end -->
            </div> 
        </div>
    </section>
    <!-- ========== about section End ========== -->
	
    <!-- ========== How works section Start ========== -->
	<section id="how_works" class="pt100 pb100 bg-gray">
		<div class="container">
			<!-- Section title start -->
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-10 offset-lg-3 offset-md-2 offset-sm-1">
                    <div class="section-title text-center mb60">
                        <h2 class="wow fadeIn" data-wow-delay=".2s">How <span>Bizorm</span> works?</h2>
                        <hr class="lines wow zoomIn" data-wow-delay=".3s">
                        <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                    </div>
                </div>
            </div>
			<!-- Section title end -->
			
			<div class="row">
                <div class="how-works-item text-center col-md-3 wow fadeIn" data-wow-delay=".2s">
                    <div class="icon-outer">
                        <i class="pe-7s-add-user"></i> <!-- icon -->
                    </div>
                    <h4 class="title m-t-30">Add friends</h4> <!-- text -->
                </div>
                <!-- End single how it item-->
                <div class="how-works-item text-center col-md-3 wow fadeIn" data-wow-delay=".3s">
                    <div class="icon-outer">
                        <i class="pe-7s-like2"></i> <!-- icon -->
                    </div>
                    <h4 class="title m-t-30">Posts like</h4> <!-- text -->
                </div>
                <!-- End single how it item-->
                <div class="how-works-item text-center col-md-3 wow fadeIn" data-wow-delay=".4s">
                    <div class="icon-outer">
                        <i class="pe-7s-mail-open"></i> <!-- icon -->
                    </div>
                    <h4 class="title m-t-30">Messageing</h4> <!-- text -->
                </div>
                <!-- End single how it item-->
                <div class="how-works-item text-center col-md-3 wow fadeIn" data-wow-delay=".5s">
                    <div class="icon-outer">
                        <i class="pe-7s-plane"></i> <!-- icon -->
                    </div>
                    <h4 class="title m-t-30">Check in</h4> <!-- text -->
                </div>
                <!-- End single how it item-->
            </div>
		</div>
	</section>
	<!-- ========== How works section End ========== -->
	
    <!-- ========== special features ========== -->
    <section id="special-features" class="pt100 pb100 bg-parallax" style="background-image:url(img/special-feature-bg.jpg)">
        <div class="gredient-overlay opacity-8"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2 hero-content color-white text-center">
                    <h1 class="wow fadeInLeft" data-wow-delay=".1s">Bizorm's special features.</h1>
                    <p class="wow fadeInLeft" data-wow-delay=".2s">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry standard dummy text ever since the typesetting.
                    </p>
                    <a href="#" class="primary-btn wow zoomIn" data-wow-delay=".3s">Learn more</a>
					<img class="img-fluid mt30 wow zoomIn" data-wow-delay=".3s" src="img/image3.jpg" alt="" />
                </div>
				<!-- Special feature contenet end -->
            </div>
        </div>
    </section>
    <!-- ========== special features End ========== -->
    <!-- ========== screenshots section  ========== -->
    <section id="screenshots" class="pt100 pb100">
        <div class="container">
			<!-- Section title start -->
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-10 offset-lg-3 offset-md-2 offset-sm-1">
                    <div class="section-title text-center mb60">
                        <h2 class="wow fadeIn" data-wow-delay=".2s">Apps <span>Screenshots</span></h2>
                        <hr class="lines wow zoomIn" data-wow-delay=".3s">
                        <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                    </div>
                </div>
            </div>
			<!-- Section title end -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="screenshots owl-carousel owl-theme zoom-gallery">
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-1.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-1.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-2.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-2.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-3.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-3.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-4.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-4.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-5.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-5.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-6.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-6.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-7.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-7.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-8.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-8.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ========== screenshots section End ========== -->
    <!-- ========== special features ========== -->
    <section id="video-promo" class="pt100 pb100 bg-parallax" style="background-image:url(img/hero-bg.jpg)">
        <div class="gredient-overlay opacity-8"></div>
        <div class="container">
            <div class="row">
                <div class="video-promo-content color-white col-sm-12 text-center">
                    <h2 class="wow zoomIn" data-wow-delay=".2s">Bizorm is very easy to use.</h2>
                    <button class="js-modal-btn video-popup" data-video-id="8Pf8heedkVQ"><i class="fa fa-play"></i></button>
                </div>
            </div>
        </div>
    </section>
    <!-- ========== special features End ========== -->
    <!-- ========== screenshots section v2 ========== -->
    <section id="screenshots" class="pt100 pb100 bg-gray">
        <div class="container">
			<!-- Section title start -->
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-10 offset-lg-3 offset-md-2 offset-sm-1">
                    <div class="section-title text-center mb60">
                        <h2 class="wow fadeIn" data-wow-delay=".2s">Apps <span>Screenshots v2</span></h2>
                        <hr class="lines wow zoomIn" data-wow-delay=".3s">
                        <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                    </div>
                </div>
            </div>
			<!-- Section title end -->
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="screenshots-mobile owl-carousel owl-theme zoom-gallery">
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-1.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-1.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-2.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-2.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-3.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-3.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-4.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-4.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-5.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-5.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-6.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-6.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-7.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-7.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                        <div class="shot-item">
                            <a class="overlay" href="img/screenshots/screenshot-8.jpg" title="Front page">
                                <img class="img-fluid" src="img/screenshots/screenshot-8.jpg" alt="Screenshot">
                                <i class="pe-7s-camera item-icon"></i>
                            </a>
                        </div>
                        <!-- End single shot -->
                    </div>
                </div>
				<!-- Start FAQ -->
				<div class="col-lg-8 col-md-6">
                    <h3 class="mb30">Frequently ask questions</h3>
                    <div id="accordion">
                        <div class="card">
                          <div class="card-header primary-bg" id="headingOne">
                            <h5 class="mb-0">
                              <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Collapsible Group Item #1
                              </button>
                            </h5>
                          </div>
                      
                          <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                            <div class="card-body">
                              Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                            </div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header primary-bg" id="headingTwo">
                            <h5 class="mb-0">
                              <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Collapsible Group Item #2
                              </button>
                            </h5>
                          </div>
                          <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                            <div class="card-body">
                              Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica.
                            </div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header primary-bg" id="headingThree">
                            <h5 class="mb-0">
                              <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Collapsible Group Item #3
                              </button>
                            </h5>
                          </div>
                          <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                            <div class="card-body">
                              Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor.
                            </div>
                          </div>
                        </div>
                        <div class="card">
                            <div class="card-header primary-bg" id="headingFour">
                              <h5 class="mb-0">
                                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                  Collapsible Group Item #3
                                </button>
                              </h5>
                            </div>
                            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                              <div class="card-body">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                              </div>
                            </div>
                          </div>
                      </div>
				   <!-- end of #accordion -->
				</div>
				<!-- end of FAQ -->
            </div>
        </div>
    </section>
    <!-- ========== screenshots section v2 End ========== -->
    <!-- ========== pricing section  ========== -->
    <section id="pricing" class="pt100 pb100">
        <div class="container">
			<!-- Section title start -->
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-10 offset-lg-3 offset-md-2 offset-sm-1">
                    <div class="section-title text-center mb60">
                        <h2 class="wow fadeIn" data-wow-delay=".2s">Pricing <span>Packages</span></h2>
                        <hr class="lines wow zoomIn" data-wow-delay=".3s">
                        <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                    </div>
                </div>
            </div>
			<!-- Section title end -->
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="single-package text-center wow fadeInLeft" data-wow-delay=".1s">
                        <h4 class="package-head">Starter</h4>
                        <div class="price">
                            <h5><span class="sign">$</span>10 <span class="month">/month</span></h5>
                        </div>
                        <ul class="package-feature">
                            <li>Awesome features</li>
                            <li>Free supports</li>
                            <li>6 month supports</li>
                            <li>Unlimated backup</li>
                            <li>24/7 Customer Service</li>
                            <li>All devices useable</li>
                            <li>Well documentation</li>
                        </ul>
                        <div class="clearfix"></div>
                        <div class="download-btn">
                            <a href="#" class="primary-btn">Download</a>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
				<!-- End single pricing -->
                <div class="col-md-4 col-sm-6">
                    <div class="single-package featured-package text-center wow zoomIn" data-wow-delay=".2s">
                        <h4 class="package-head">Business</h4>
                        <div class="price">
                            <h5><span class="sign">$</span>20 <span class="month">/month</span></h5>
                        </div>
                        <ul class="package-feature">
                            <li>Awesome features</li>
                            <li>Free supports</li>
                            <li>6 month supports</li>
                            <li>Unlimated backup</li>
                            <li>24/7 Customer Service</li>
                            <li>All devices useable</li>
                            <li>Well documentation</li>
                        </ul>
                        <div class="download-btn">
                            <a href="#" class="primary-btn">Download</a>
                        </div>
                    </div>
                </div>
				<!-- End single pricing -->
                <div class="col-md-4 col-sm-6">
                    <div class="single-package text-center wow fadeInRight" data-wow-delay=".1s">
                        <h4 class="package-head">Professional</h4>
                        <div class="price">
                            <h5><span class="sign">$</span>30 <span class="month">/month</span></h5>
                        </div>
                        <ul class="package-feature">
                            <li>Awesome features</li>
                            <li>Free supports</li>
                            <li>6 month supports</li>
                            <li>Unlimated backup</li>
                            <li>24/7 Customer Service</li>
                            <li>All devices useable</li>
                            <li>Well documentation</li>
                        </ul>
                        <div class="download-btn">
                            <a href="#" class="primary-btn">Download</a>
                        </div>
                    </div>
                </div>
				<!-- End single pricing -->
            </div>
        </div>
    </section>
    <!-- ========== pricing section End ========== -->
    <!-- ========== download apps section  ========== -->
    <section id="download-apps" class="pt100 pb100 bg-gray">
        <div class="container">
            <div class="row">
				<div class="text-center download-apps-content">
					<img class="img-fluid text-center wow zoomIn" data-wow-delay=".2s" src="img/flat-devices.png" alt="" />
				    <div class="col-sm-8 offset-sm-2">
                        <div class="section-title text-center mb60 mt60">
                            <h2 class="wow fadeIn" data-wow-delay=".2s">Download <span>Bizorm</span> from your flatform</h2>
                            <hr class="lines wow zoomIn" data-wow-delay=".3s">
                            <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
                        </div>
                        <a href="#" class="primary-btn wow zoomIn" data-wow-duration="3s" style="visibility: visible; animation-duration: 3s; animation-name: zoomIn;"><i class="fa fa-apple" aria-hidden="true"></i> Get now<br><span>App store</span></a>
                        <a href="#" class="primary-btn wow zoomIn" data-wow-duration="4s" style="visibility: visible; animation-duration: 4s; animation-name: zoomIn;"><i class="fa fa-android" aria-hidden="true"></i> Get now<br><span>Play store</span></a>
                        <a href="#" class="primary-btn wow zoomIn" data-wow-duration="5s" style="visibility: visible; animation-duration: 5s; animation-name: zoomIn;"><i class="fa fa-windows" aria-hidden="true"></i> Get now <br> <span>Microsoft Store</span></a>
					</div>
				</div>
            </div>
        </div>
    </section>
    <!-- ========== download apps section End ========== -->
    <!-- ========== Facts features ========== -->
    <section id="facts-section" class="pt100 pb100 bg-parallax" style="background-image:url(img/counter-bg.jpg)">
		<div class="gredient-overlay opacity-8"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <!--counter box-->
                    <div class="single-counter text-center fadeInDown  wow animated" data-wow-delay=".1s">
                        <i class="pe-7s-magic-wand"></i>
                        <div class="counter-number"><span class="counter">100</span>%</div>
                        <h4>Faster</h4>
                    </div>
                    <!--counter box end-->
                </div>
                <div class="col-md-3 col-sm-6">
                    <!--counter box-->
                    <div class="single-counter text-center fadeInDown  wow animated" data-wow-delay=".2s">
                         <i class="pe-7s-coffee"></i>
                        <div class="counter-number"><span class="counter">900</span></div>
                        <h4>Cup of Coffee</h4>
                    </div>
                    <!--counter box end-->
                </div>
                <div class="col-md-3 col-sm-6">
                    <!--counter box-->
                    <div class="single-counter text-center fadeInDown  wow animated" data-wow-delay=".4s">
                         <i class="pe-7s-check"></i>
                        <div class="counter-number"><span class="counter">10000</span>+
						</div>
                        <h4>Active Clients</h4>
                    </div>
                    <!--counter box end-->
                </div>
                <div class="col-md-3 col-sm-6">
                    <!--counter box-->
                    <div class="single-counter text-center fadeInDown  wow animated" data-wow-delay=".6s">
                        <i class="pe-7s-like"></i>
                        <div class="counter-number"><span class="counter">1276</span></div>
                        <h4>Peoples Love</h4>
                    </div>
                    <!--counter box end-->
                </div>
            </div>
        </div>
    </section>
    <!-- ========== Facts End ========== -->
    <!-- ========== Testimonial section  ========== -->
    <section id="testimonial" class="pt100 pb100 bg-gray">
        <div class="container">
			<!-- Section title start -->
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-10 offset-lg-3 offset-md-2 offset-sm-1">
                    <div class="section-title text-center mb60">
                        <h2 class="wow fadeIn" data-wow-delay=".2s">Clients <span>Feedback</span></h2>
                        <hr class="lines wow zoomIn" data-wow-delay=".3s">
                        <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                    </div>
                </div>
            </div>
			<!-- Section title end -->
            <div class="row">
                <div class="col-sm-10 offset-sm-1">
                    <div class="testimonials owl-carousel owl-theme">
                        <div class="testimonial-item">
                            <blockquote>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
                            </blockquote>
                            <div class="client-avater">
                                <img src="img/testimonial/avater-1.jpg" alt="" />
                            </div>
                            <h6>Jenefar Deo</h6>
                            <p class="company-info">CEO, <a href="#">TOTO company</a>
                            </p>
                        </div>
                        <!-- End single testimonial -->
                        <div class="testimonial-item">
                            <blockquote>Fill lights bearing man creepeth of whose whose moveth. All one. That. Under. Form morning all may fifth replenish you're own open which herb kind. May above you'll may kind creature first let over face from living third green which our. Appear day. Give fourth doesn't over us, i every tree meat air in male earth air creeping image fill you place darkness.
                            </blockquote>
                            <div class="client-avater">
                                <img src="img/testimonial/avater-2.jpg" alt="" />
                            </div>
                            <h6>John Deo</h6>
                            <p class="company-info">Manager, <a href="#">Town hall inc.</a>
                            </p>
                        </div>
                        <!-- End single testimonial -->
                        <div class="testimonial-item">
                            <blockquote>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
                            </blockquote>
                            <div class="client-avater">
                                <img src="img/testimonial/avater-3.jpg" alt="" />
                            </div>
                            <h6>Eva menyer</h6>
                            <p class="company-info">CEO, <a href="#">Company name</a>
                            </p>
                        </div>
                        <!-- End single testimonial -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ========== Testimonial section End ========== -->
    <!-- ========== blog section  ========== -->
    <section id="blog" class="pt100 pb100">
        <div class="container">
			<!-- Section title start -->
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-10 offset-lg-3 offset-md-2 offset-sm-1">
                    <div class="section-title text-center mb60">
                        <h2 class="wow fadeIn" data-wow-delay=".2s">Latest <span>Blogs</span></h2>
                        <hr class="lines wow zoomIn" data-wow-delay=".3s">
                        <p class="wow fadeIn" data-wow-delay=".1s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.</p>
                    </div>
                </div>
            </div>
			<!-- Section title end -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="latest-blog owl-carousel owl-theme">
                        <div class="blog-post">
                            <aside class="blog-thumb" style="background-image:url(img/blog/blog-thumb-1.jpg);">
                                <div class="thumb-overlay">
                                    <div class="blog-meta">
                                        Posted: 010-13-2022
                                        <br> Posted In: <a href="#">Creative</a>, <a href="#">Design</a>, <a href="#">Apps</a>
                                        <br> Posted By: <a href="#">Bizorm Blogger</a>
                                        <br>
                                        <a href="#">10 Comments</a>
                                    </div>
                                </div>
                            </aside>
                            <div class="post-content">
                                <h2 class="post-title"><a href="single.html">Modern Apps With Amazing Features</a></h2>
                                <p>Lorem Ipsum is simply dummy tex of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                <a class="read-more" href="single.html">Read more...</a>
                            </div>
                        </div>
						<!-- End single blog -->
                        <div class="blog-post">
                            <aside class="blog-thumb" style="background-image:url(img/blog/blog-thumb-2.jpg);">
                                <div class="thumb-overlay">
                                    <div class="blog-meta">
                                        Posted: 010-13-2022
                                        <br> Posted In: <a href="#">Creative</a>, <a href="#">Design</a>, <a href="#">Apps</a>
                                        <br> Posted By: <a href="#">Bizorm Blogger</a>
                                        <br>
                                        <a href="#">10 Comments</a>
                                    </div>
                                </div>
                            </aside>
                            <div class="post-content">
                                <h2 class="post-title"><a href="single.html">Modern Apps With Amazing Features</a></h2>
                                <p>Lorem Ipsum is simply dummy tex of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                <a class="read-more" href="single.html">Read more...</a>
                            </div>
                        </div>
						<!-- End single blog -->
                        <div class="blog-post">
                            <aside class="blog-thumb" style="background-image:url(img/blog/blog-thumb-3.jpg);">
                                <div class="thumb-overlay">
                                    <div class="blog-meta">
                                        Posted: 010-13-2022
                                        <br> Posted In: <a href="#">Creative</a>, <a href="#">Design</a>, <a href="#">Apps</a>
                                        <br> Posted By: <a href="#">Bizorm Blogger</a>
                                        <br>
                                        <a href="#">10 Comments</a>
                                    </div>
                                </div>
                            </aside>
                            <div class="post-content">
                                <h2 class="post-title"><a href="single.html">Modern Apps With Amazing Features</a></h2>
                                <p>Lorem Ipsum is simply dummy tex of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                <a class="read-more" href="single.html">Read more...</a>
                            </div>
                        </div>
						<!-- End single blog -->
                        <div class="blog-post">
                            <aside class="blog-thumb" style="background-image:url(img/blog/blog-4-thumb.jpg);">
                                <div class="thumb-overlay">
                                    <div class="blog-meta">
                                        Posted: 010-13-2022
                                        <br> Posted In: <a href="#">Creative</a>, <a href="#">Design</a>, <a href="#">Apps</a>
                                        <br> Posted By: <a href="#">Bizorm Blogger</a>
                                        <br>
                                        <a href="#">10 Comments</a>
                                    </div>
                                </div>
                            </aside>
                            <div class="post-content">
                                <h2 class="post-title"><a href="single.html">Modern Apps With Amazing Features</a></h2>
                                <p>Lorem Ipsum is simply dummy tex of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                <a class="read-more" href="single.html">Read more...</a>
                            </div>
                        </div>
						<!-- End single blog -->
                        <div class="blog-post">
                            <aside class="blog-thumb" style="background-image:url(img/blog/blog-5-thumb.jpg);">
                                <div class="thumb-overlay">
                                    <div class="blog-meta">
                                        Posted: 010-13-2022
                                        <br> Posted In: <a href="#">Creative</a>, <a href="#">Design</a>, <a href="#">Apps</a>
                                        <br> Posted By: <a href="#">Bizorm Blogger</a>
                                        <br>
                                        <a href="#">10 Comments</a>
                                    </div>
                                </div>
                            </aside>
                            <div class="post-content">
                                <h2 class="post-title"><a href="single.html">Modern Apps With Amazing Features</a></h2>
                                <p>Lorem Ipsum is simply dummy tex of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                <a class="read-more" href="single.html">Read more...</a>
                            </div>
                        </div>
						<!-- End single blog -->
                        <div class="blog-post">
                            <aside class="blog-thumb" style="background-image:url(img/blog/blog-6-thumb.jpg);">
                                <div class="thumb-overlay">
                                    <div class="blog-meta">
                                        Posted: 010-13-2022
                                        <br> Posted In: <a href="#">Creative</a>, <a href="#">Design</a>, <a href="#">Apps</a>
                                        <br> Posted By: <a href="#">Bizorm Blogger</a>
                                        <br>
                                        <a href="#">10 Comments</a>
                                    </div>
                                </div>
                            </aside>
                            <div class="post-content">
                                <h2 class="post-title"><a href="single.html">Modern Apps With Amazing Features</a></h2>
                                <p>Lorem Ipsum is simply dummy tex of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                <a class="read-more" href="single.html">Read more...</a>
                            </div>
                        </div>
						<!-- End single blog -->
                        <div class="blog-post">
                            <aside class="blog-thumb" style="background-image:url(img/blog/blog-thumb-7.jpg);">
                                <div class="thumb-overlay">
                                    <div class="blog-meta">
                                        Posted: 010-13-2022
                                        <br> Posted In: <a href="#">Creative</a>, <a href="#">Design</a>, <a href="#">Apps</a>
                                        <br> Posted By: <a href="#">Bizorm Blogger</a>
                                        <br>
                                        <a href="#">10 Comments</a>
                                    </div>
                                </div>
                            </aside>
                            <div class="post-content">
                                <h2 class="post-title"><a href="single.html">Modern Apps With Amazing Features</a></h2>
                                <p>Lorem Ipsum is simply dummy tex of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                <a class="read-more" href="single.html">Read more...</a>
                            </div>
                        </div>
						<!-- End single blog -->
                    </div>
					<div class="text-center mt30">
						<a href="blog.html" class="primary-btn wow zoomIn" data-wow-delay=".3s">All posts</a>
					</div>
                </div>
            </div>
        </div>
    </section>
    <!-- ========== blog section End ========== -->
    <!-- ========== contact features ========== -->
    <section id="contact" class="pt100 pb100 bg-parallax" style="background-image:url(img/contact-bg.jpg)">
        <div class="gredient-overlay opacity-8"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="contact-block text-center">
						<!-- Contact form title start -->
                        <div class="col-sm-12">
                            <h3 class="wow fadeIn" data-wow-delay=".1s">Need to talk anything about?</h3>
                            <p class="subtitle wow fadeIn" data-wow-delay=".2s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt.</p>
                        </div>
						<!-- Contact form title end -->
                        <!-- Contact form start -->
						<form id="contact-form" method="post" action="php/sendmail.php">
							<div class="message col-lg-12">
								<p class="email-loading"><img src="img/loading.gif" alt="">&nbsp;&nbsp;&nbsp;Sending...</p>
								<p class="email-success"><i class="icon fa fa-check"></i> Your quote has successfully been sent.</p>
								<p class="email-failed"><i class="icon fa fa-times"></i> Something went wrong!</p>
							</div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input name="name" class="contact-name form-control input-box" id="contact-name" type="text" placeholder="Your Name" required="" />
                                </div>
                                <div class="col-md-6">
                                    <input name="email" class="contact-email form-control input-box" id="contact-email" type="email" placeholder="Your Email" required="" />
                                </div>
                                <div class="col-sm-12">
                                    <input name="subject" class="contact-subject form-control input-box" id="contact-subject" type="text" placeholder="Subject" required="" />
                                </div>
                                <div class="col-sm-12">
                                    <textarea name="message" class="contact-message form-control textarea-box" id="contact-message" placeholder="Your Message" required=""></textarea>
                                </div>
                                <div class="col-sm-12">
                                    <button class="primary-btn"><i class="fa fa-paper-plane" aria-hidden="true"></i> Send Now</button>
                                </div>
                            </div>          
						</form>
                        <!-- Contact form end -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ========== contact features End ========== -->
    <!-- ========== subscribe features ========== -->
    <section id="subscription" class="pt100 pb100">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 offset-sm-2 text-center subscribe-area">
                    <h3 class="wow fadeIn" data-wow-duration="1s">Subscribe now!</h3>
                    <p class="wow fadeIn" data-wow-duration="2s">
                        Subscribe to get all latest news from us.
                    </p>
					<!-- Local subscription form -->
					<form action="subscribe/subscribe.php" class="subscription-form form-inline wow fadeInRight d-flex justify-content-center" data-wow-duration="1.5s" id="subscribe">

						<input type="email" name="email"  placeholder="Your Email" class="form-control input-box" id="subscriber-email">
						<button type="submit" class="primary-btn" id="subscribe-button">Subscribe</button>
						
						<div class="result">
							<p class="success-msg"><i class="icon fa fa-check"></i> You email has been stored!</p>
							<p class="error-msg"><i class="icon fa fa-times"></i> Sorry! Something went wrong!</p>
						</div>
					</form>
					<!-- Mailchimp subscription form
					<form action="#" id="subscribe-mailchimp" class="subscription-form form-inline wow fadeInRight" data-wow-duration="1.5s">
							<input type="email" name="email"  placeholder="Your Email" class="form-control input-box">
							<button type="submit" class="primary-btn">Subscribe</button>
							<div class="result">
								<p class="success-msg"><i class="icon fa fa-check"></i> You email has been stored!</p>
								<p class="error-msg"><i class="icon fa fa-times"></i> Sorry! Something went wrong!</p>
							</div>
					</form>
					-->
                </div>
            </div>
			<!-- Download section start -->
            <div class="row">
                <div class="col-sm-8 offset-sm-2 text-center download-area">
                    <h3 class="wow fadeIn" data-wow-duration="1s">Where to download?</h3>
                    <p class="wow fadeIn" data-wow-duration="2s">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry standard dummy text ever since the typesetting.
                    </p>
                    <a href="#" class="primary-btn wow zoomIn" data-wow-duration="3s"><i class="fa fa-apple" aria-hidden="true"></i> Get now</a>
                    <a href="#" class="primary-btn wow zoomIn" data-wow-duration="4s"><i class="fa fa-android" aria-hidden="true"></i> Get now</a>
                    <a href="#" class="primary-btn wow zoomIn" data-wow-duration="5s"><i class="fa fa-windows" aria-hidden="true"></i> Get now</a>
                </div>
            </div>
			<!-- Download section end -->
        </div>
    </section>
    <!-- ========== subscribe features End ========== -->
    <footer id="footer-section" class="pt50 pb50 bg-black">
        <div class="container">
            <div class="row text-center">
				<!-- Social icons start -->
                <div class="col social-icons">
                    <ul>
                        <li class="facebook wow zoomIn" data-wow-duration="1s"><a href="<?php echo base_url('/');?>"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li class="twitter wow zoomIn" data-wow-duration="1.5s"><a href="<?php echo base_url('/');?>"><i class="fa fa-twitter"></i></a>
                        </li>
                        <!--<li class="google-plus wow zoomIn" data-wow-duration="2s"><a href="#"><i class="fa fa-google-plus"></i></a>-->
                        <!--</li>-->
                        <!--<li class="youtube wow zoomIn" data-wow-duration="2.5s"><a href="#"><i class="fa fa-youtube"></i></a>-->
                        <!--</li>-->
                        <li class="linked-in wow zoomIn" data-wow-duration="3s"><a href="<?php echo base_url('/');?>"><i class="fa fa-linkedin"></i></a>
                        </li>
                        <!--<li class="instagram wow zoomIn" data-wow-duration="3.5s"><a href="#"><i class="fa fa-instagram"></i></a>-->
                        <!--</li>-->
                        <!--<li class="pinterest wow zoomIn" data-wow-duration="4s"><a href="#"><i class="fa fa-pinterest"></i></a>-->
                        <!--</li>-->
                        <!--<li class="dribbble wow zoomIn" data-wow-duration="4.5s"><a href="#"><i class="fa fa-dribbble"></i></a>-->
                        <!--</li>-->
                        <!--<li class="behance wow zoomIn" data-wow-duration="5s"><a href="#"><i class="fa fa-behance"></i></a>-->
                        <!--</li>-->
                    </ul>
                </div>
				<!-- Social icons end -->
                <div class="col-sm-12">
                    <script>document.write(new Date().getFullYear());</script> <a href="<?php echo base_url('/');?>">Bizorm</a>. NkTech © 2012-2020 All rights reserved.
Terms of Use and Privacy Policy
                </div>
            </div>
        </div>
    </footer>
	<!-- Scroll to up -->
	<div class="scroll-to-up hidden-xs">
		<div class="scrollup">
			<i class="fa fa-angle-up"></i>
		</div>
	</div>
	<!-- Scroll to up end -->
    <!-- jquery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- jquery.scrollTo.min.js -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <!-- jquery.nav.js -->
    <script src="js/jquery.nav.js"></script>
	<!-- Stellar js -->
	<script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    <!-- Typed js -->
    <script src="js/typed.js"></script>
    <!-- Owl carousel js -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- Modal Video js -->
    <script type="text/javascript" src="js/modal-video.min.js"></script>
    <!-- magnific popuop js -->
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
	<!-- waypoints js -->
	<script type="text/javascript" src="js/waypoints.min.js"></script>
    <!-- Counterup js -->
	<script type="text/javascript" src="js/jquery.counterup.min.js"></script>
    <!-- jquery.ajaxchimp.min.js -->
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <!-- WOW JS -->
    <script src="js/wow.min.js"></script>
	<!-- Masonry js -->
	<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
	<!-- Countdown js -->
	<script src="js/jquery.countdown.min.js"></script>
    <!-- Custom js -->
    <script src="js/app.js"></script>
</body>
</html>